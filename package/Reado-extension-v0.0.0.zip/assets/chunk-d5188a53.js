var r=(_=>(_.CLICKED_ON_CONTEXT_MENU="clicked_browser_action",_.STYLE_UPDATE="update_style",_))(r||{});export{r as E};
