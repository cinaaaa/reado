const e=document.querySelector("body"),o=document.createElement("section");chrome.runtime.onMessage.addListener((t,n)=>{t.selectedText.length>1&&i(t.selectedText)});e.addEventListener("click",t=>{t.target&&t.target.classList.contains("close-button-content")&&s()});e.addEventListener("keydown",t=>{if(t.ctrlKey&&t.key==="m"){const n=window.getSelection(),c=n==null?void 0:n.toString().trim();c&&c.length>1&&i(c)}t.key==="Escape"&&s()});function i(t){o.classList.add("text-section-parent"),e.style.overflow="hidden",e.appendChild(o),o.innerHTML=`
    <div class="text-selection-content">
      <svg class="close-button-content" x="0px" y="0px" width="25" height="25" viewBox="0 0 50 50">
      <path d="M 7.71875 6.28125 L 6.28125 7.71875 L 23.5625 25 L 6.28125 42.28125 L 7.71875 43.71875 L 25 26.4375 L 42.28125 43.71875 L 43.71875 42.28125 L 26.4375 25 L 43.71875 7.71875 L 42.28125 6.28125 L 25 23.5625 Z"></path>
      </svg>
      <p>${t}</p>
    </div>
    `}function s(){e.removeChild(o),e.style.overflow="auto"}
