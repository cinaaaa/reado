(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-6f6bb13e.js")
    );
  })().catch(console.error);

})();
