const s=function(){const o=document.createElement("link").relList;if(o&&o.supports&&o.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))a(e);new MutationObserver(e=>{for(const i of e)if(i.type==="childList")for(const r of i.addedNodes)r.tagName==="LINK"&&r.rel==="modulepreload"&&a(r)}).observe(document,{childList:!0,subtree:!0});function n(e){const i={};return e.integrity&&(i.integrity=e.integrity),e.referrerpolicy&&(i.referrerPolicy=e.referrerpolicy),e.crossorigin==="use-credentials"?i.credentials="include":e.crossorigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function a(e){if(e.ep)return;e.ep=!0;const i=n(e);fetch(e.href,i)}};s();const l=["fontSize","fontFamily","lineHeight","letterSpacing","wordSpacing","textAlign","backgroundOpacity","textBackgroundColor","textColor"];function c(){const t=["fontSize","fontFamily","lineHeight","letterSpacing","wordSpacing","textAlign","backgroundOpacity","textBackgroundColor","textColor"];for(let o of t)try{let n=document.getElementById(o),a=document.getElementById(`${o}Value`);a&&(a.innerHTML=n.value),localStorage.setItem(o,n.value),console.log("updated "+o),console.log("value is  => "+n.value)}catch{console.log(o+" not found")}}function d(){for(let t of l){let o=document.getElementById(t),n=document.getElementById(`${t}Value`),a=localStorage.getItem(t)||null;try{a&&(o.value=a,n.innerHTML=a)}catch{console.log(t+" not found")}}}document.addEventListener("change",function(t){t.target&&l.includes(t.target.id)&&c()});document.addEventListener("DOMContentLoaded",function(){d()});chrome.runtime.onMessage.addListener(function(t,o,n){t.message==="clicked_browser_action"&&d()});document.querySelector("#app").innerHTML=`
  <main id="reado--component">
  <h1 class="reado--h1">Reado</h1>
  <h2 class="reado--h2">Adjust your reading preferences</h2>
  <div class="reado--grid-container">
    <div class="reado--grid-item">
      <h3>Font Size</h3>
      <input type="range" min="1" max="100" value="50" class="reado--slider reado" id="fontSize">
      <span id="fontSizeValue" class="reado">50</span>
    </div>
    <div class="reado--grid-item">
      <h3>Font Family</h3>
      <select name="font-family" id="fontFamily">
        <option value="sans-serif">Sans-serif</option>
        <option value="serif">Serif</option>
        <option value="monospace">Monospace</option>
        <option value="roboto">Roboto</option>
      </select>
    </div>
    <div class="reado--grid-item">
      <h3>Line Height</h3>
      <input type="range" min="1" max="100" value="50" class="reado--slider" id="lineHeight">
      <span id="lineHeightValue">50</span>
    </div>
    <div class="reado--grid-item">
      <h3>Letter Spacing</h3>
      <input type="range" min="1" max="100" value="50" class="reado--slider" id="letterSpacing">
      <span id="letterSpacingValue">50</span>
    </div>
    <div class="reado--grid-item">
      <h3>Word Spacing</h3>
      <input type="range" min="1" max="100" value="50" class="reado--slider" id="wordSpacing">
      <span id="wordSpacingValue">50</span>
    </div>
    <div class="reado--grid-item">
      <h3>Text Align</h3>
      <select name="text-align" id="textAlign">
        <option value="left">Left</option>
        <option value="center">Center</option>
        <option value="right">Right</option>
      </select>
    </div>
    <div class="reado--grid-item">
      <h3>Background Opacity</h3>
      <input type="range" min="1" max="100" value="50" class="reado--slider" id="backgroundOpacity">
      <span id="backgroundOpacityValue">50</span>
    </div>
    <div class="reado--grid-item">
      <h3>Text Background Color</h3>
      <input type="color" id="textBackgroundColor" name="text-background-color" value="#ffffff">
    </div>
    <div class="reado--grid-item">
      <h3>Text Color</h3>
      <input type="color" id="textColor" name="text-color" value="#000000" onchange="alert('test')">
    </div>
  </div>
</main>
`;
