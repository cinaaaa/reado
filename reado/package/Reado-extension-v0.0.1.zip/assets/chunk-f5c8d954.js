const n=document.querySelector("body"),e=document.createElement("section");e.classList.add("text-section-parent");chrome.runtime.onMessage.addListener((t,c)=>t.selectedText.length>1?(n.appendChild(e),e.innerHTML=`
    <div class="text-selection-content">
      <p>${t.selectedText}</p>
    </div>
    `,!0):!1);
