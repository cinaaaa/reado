(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-f5c8d954.js")
    );
  })().catch(console.error);

})();
