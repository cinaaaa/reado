(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-caa86da0.js")
    );
  })().catch(console.error);

})();
